# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]
 

	
def depthFirstSearch(problem):


	#print "Start:", problem.getStartState()
	#print "Is the start a goal?", problem.isGoalState(problem.getStartState())
	#print "Start's successors:", problem.getSuccessors(problem.getStartState())
	moveStack = util.Stack()
	moveStack.push([problem.getStartState(),[]]) #movestack holds both current location and list of directions to get to curr location
	marked = [] #these are the visited items
	moveDict = {} #dict to store prev to curr move mapping
	pathTaken = [] #this just holds a list of directions taken to get to a specific location
	goalFound = False #condition checking to break while loop
	#prevDirect = "start"	
	while not moveStack.isEmpty(): #continue while there are items in the stack
		currLine = moveStack.pop() #curr line holds both the loc and directions for getting there
		currState = currLine[0] #output the current loc into currState: (x,y)
		directions =currLine[1] #put the directinos for getting there into actions
		marked.append(currState) #mark the current location
		if problem.isGoalState(currState): #check the goal condition
				totalPath = directions 
				return totalPath
		#if currState not in marked:
		#marked.append(currState)
		for i in problem.getSuccessors(currState): #for each available move
			if i[0] not in marked:
				moveStack.push([i[0], directions + [i[1]]]) #push the new location along with updated directions to the stack			

def breadthFirstSearch(problem):
	moveQueue = util.Queue() #simple queue to fold the locations and directions to locs
	moveQueue.push([problem.getStartState(),[]]) #adds the starting loc with a direction of []
	moveDict = {} #maps children to parents
	marked = [] #this is for the items that have been completely explored and have no more available moves
	alreadyExp =[] #this is for the items on the border that are not marked yet
	pathTaken = [] #this keeps track of path taken to the goal
	goalFound = False
	#prevDirect = "start"
	while not moveQueue.isEmpty():
		currLine = moveQueue.pop() #this item holds both the location and direction to that loc
		currLoc = currLine[0] #here i seperate the loc and dir into two seperate objects
		print "current location: ", currLoc
		#print "data type of currLoc: ", type(currLoc)
		directions = currLine[1]
		print "currend directions: ", directions 
		#print "current directions: ", directions
		#print "data type of directions: ", type(directions)

		marked.append(currLoc) #mark the first item as black
		#print currState, " just visited"
		#moveDict[currState] = pathTaken.append(prevDirect"
		if problem.isGoalState(currLoc):
			print "in goal state"
			print "goal state directions: ", directions
			return directions
			#print "Goal Found."
		else:
			for i in problem.getSuccessors(currLoc): #for every available move:
				if i[0] not in marked and i[0] not in alreadyExp: # make sure these items have not already been added
					alreadyExp.append(i[0]) #mark these as border items
					newDirections = directions + [i[1]]	 #add the latest move to the directions
					moveQueue.push([i[0],newDirections])	
	return []							
	

'''
	Problem: Failing the lasst test 
		The nodes are appended to the fringe as soon as 
		they are pushed onto the priority queue. They are not 
		necessarily added to fringe in the priority order. 
		Thus, some longer paths to a node might be 
		added to the fringe before some shorter paths
		and the shorter paths therefore never get 
		pushed (because paths are only pushed if they 
		are not in fringe.)
		
		We need a condition that checks for the elements
		that are already in fringe. If a location in 
		fringe with high path size is already in the stack, 
		we need a function that will update that 
		path with a shorter path. The update functino 
		is designed to do that, however it is failing 
		because i am not inputting the desired data structure.
		
		solution: seperate the location and paths into two seperate entities. 
		This way, the update 
'''

def uniformCostSearch(problem):
	moveQueue = util.PriorityQueue()
	moveQueue.push((problem.getStartState(),[]),0)
	marked = []
	fringe = {}
	while not moveQueue.isEmpty():
		currLine = moveQueue.pop()
		currLoc = currLine[0]
		#print "Just popped ", currLoc
		directions = currLine[1]
		#print "directions to here: ", directions
		if problem.isGoalState(currLoc):
			return directions
		marked.append(currLoc)
		#print "Marked: "
		#for i in marked:
	#		print(i)
		#print "successors of ", currLoc, " ", problem.getSuccessors(currLoc)
		
		for loc, dir,num in problem.getSuccessors(currLoc):
			if loc not in marked:
				if loc not in fringe:
					newDirections = directions + [dir]
					moveQueue.push
					cost = problem.getCostOfActions(newDirections)
					moveQueue.push((loc, newDirections),cost)
					fringe[loc] = cost
				else:
					newDirections = directions + [dir]
					moveQueue.push
					fCost = fringe[loc]
					if cost < fCost:
						moveQueue.push((loc, newDirections),cost)
						fringe[loc] = cost
		
		

					
				 #PROBLEM: the item that is being updated includes directions. since the dirctions are different, different
					#print "Just pushed ", loc, " with path cost ", problem.getCostOfActions(newDirections)
					#else:
					#	moveQueue.update([loc,newDirections], problem.getCostOfActions(newDirections))
					
				#Removing this function gives me 10 error, including it gives me 1
				#else:
				#	fringe.append(loc)
				#	newDirections = directions + [dir]
				##	moveQueue.push([loc,newDirections], problem.getCostOfActions(newDirections))
#Question: Do I even need the bottom function? 
#Why are some nodes being repeated 
#nodes are repeated when I am incorrectly testing if a node is a goal before adding it to the queue, instead of testing when you remove the node			


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0



def aStarSearch(problem, heuristic=nullHeuristic):
	moveQueue = util.PriorityQueue()
	startingScore = heuristic(problem.getStartState(),problem)
	moveQueue.push((problem.getStartState(),[]),startingScore)
	marked = []
	fringe = {}
	while not moveQueue.isEmpty():
		currLine = moveQueue.pop()
		currLoc = currLine[0]
		#print "Just popped ", currLoc
		directions = currLine[1]
		#print "directions to here: ", directions
		if problem.isGoalState(currLoc):
			return directions
		marked.append(currLoc)
		#print "Marked: "
		#for i in marked:
	#		print(i)
		#print "successors of ", currLoc, " ", problem.getSuccessors(currLoc)
		
		for loc, dir,num in problem.getSuccessors(currLoc):
			if loc not in marked:
				if loc not in fringe:
					#push all locations not in the fringe or marked
					newDirections = directions + [dir]
					cost = problem.getCostOfActions(newDirections)
					points = cost + heuristic(loc,problem)
					moveQueue.push((loc, newDirections),points)
					#since this loc has never been seen, I know this is the min val
					fringe[loc] = points
				else: #here I allow fringe items through with the intent of only adding cheaper paths to the same location
					newDirections = directions + [dir]
					cost = problem.getCostOfActions(newDirections)
					points = cost + heuristic(loc,problem)
					#moveQueue.push
					fPoints = fringe[loc]
					if points < fPoints: #this checks to see if new path is better
						moveQueue.push((loc, newDirections),points) #only add a new path if it is shorter
						fringe[loc] = points
	
	
# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch

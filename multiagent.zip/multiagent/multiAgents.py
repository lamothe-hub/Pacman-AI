#-----------------------------
#Jeffrey Lamothe
#HW2
# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):

	def getAction(self, gameState):
		# Collect legal moves and successor states
		legalMoves = gameState.getLegalActions()
		scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
		bestScore = max(scores)
		bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
		chosenIndex = random.choice(bestIndices) # Pick randomly among the best
		return legalMoves[chosenIndex]
		
	def evaluationFunction(self, currentGameState, action):
		# Useful information you can extract from a GameState (pacman.py)
		successorGameState = currentGameState.generatePacmanSuccessor(action)
		newPos = successorGameState.getPacmanPosition()
		newFood = successorGameState.getFood()
		currFood = currentGameState.getFood()
		newGhostStates = successorGameState.getGhostStates()
		newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
		value = 0
		#this ensures that if there is a ghost less than 2 away, the pacman always goes in another direction
		#this is by far the most heavily-weighted function.
		ghostValue = 0
		for ghostState in newGhostStates: #for each ghost 
			seperation = manhattanDistance(newPos, ghostState.getPosition())
			if seperation < 2: #if this move will cause pacman to collide with ghost
				ghostValue = -1000000
		#this is a more general function for generally avoiding ghosts. 
		#Although it is most important to not hit a ghost, it helps to stay as far away as you can to avoid being cornered
		otherGhostValue = 0
		totalSep = 0
		for ghostState in newGhostStates:
			seperation = manhattanDistance(newPos, ghostState.getPosition())
			totalSep = totalSep + seperation
		otherGhostValue = totalSep/2
		#Eating nearby food first is better than eating far away food first and having to come back
		#this incentivizes eating nearby food first:
		foodValue = 0.0
		amountNewFood = len(newFood.asList())
		amountCurrFood = len(currFood.asList())
		if amountNewFood < amountCurrFood:
			foodValue = 5
		#sometimes there is no nearby food. In this case, it is important to go toward a food dot
		#more general incentive to choose paths to find far away food
		minManhat = 100000
		distances = []
		for dot in currFood.asList():
			dist = manhattanDistance(dot, newPos)
			distances.append(dist)
			if dist < minManhat:
				minManhat = dist
		dotValue = -minManhat*2
		#calculating std. deviation of distances from pacman
		#all else aside, if given the option, it is better to leave dots clustered together, rather than spread out. 
		#this incentivizes entering states that will not leave dots stranded.
		mean = 0.0
		for distance in distances:
			mean = mean + distance
		mean = mean/len(distances)
		meanValue = -1 * mean * .3
		value = ghostValue + foodValue + dotValue +otherGhostValue + meanValue
		return value
		
def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
	def getAction(self, gameState):
		if gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		else:
			legalMoves = gameState.getLegalActions(0)
			nextStates = []
			values = []
			for move in legalMoves:
				#generate states for each move
				nextStates.append(gameState.generateSuccessor(0,move))
			for state in nextStates:
				#populate values with a list of a value for each corresponding state
				valTemp = self.minFinder(state, 1, self.depth)
				values.append(valTemp)
			maxVal = max(values)
			i = 0

			for value in values:
				if value == maxVal:
					maxValIndex =i
				i=i+1
			move = legalMoves[maxValIndex]
			return move
			
		
	def maxFinder(self, gameState, depth):
		if depth == 0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		
		maxVal = -99999
		nextStates = []
		legalMoves = gameState.getLegalActions(0)
		for move in legalMoves:
			nextStates.append(gameState.generateSuccessor(0,move))
		for state in nextStates:
			valTemp = self.minFinder(state, 1, depth)
			#thus minFinder must return the value of the node.
			if valTemp > maxVal:
				maxVal = valTemp
		return maxVal
	
	def minFinder(self, gameState, agent, depth):
		if depth ==0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		numAgents = gameState.getNumAgents()
		legalMoves = gameState.getLegalActions(agent)
		nextStates = []
		#generate states for each legal move
		for move in legalMoves:
			nextStates.append(gameState.generateSuccessor(agent,move))
		
		#find the min value
		minValue = 999999
		if agent == numAgents -1:
			for state in nextStates:
				valTemp = self.maxFinder(state,depth-1)
				if valTemp <minValue:
					minValue = valTemp
		else:
			for state in nextStates:
				valTemp = self.minFinder(state, agent + 1, depth)
				if valTemp <minValue:
					minValue = valTemp
		return minValue
	
    	

class AlphaBetaAgent(MultiAgentSearchAgent):
	def getAction(self, gameState):
		if gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		else:
			legalMoves = gameState.getLegalActions(0)
			nextStates = []
			values = []
			maxVal = -9999999
			a = -9999999
			b = 99999999
			for move in legalMoves:
				state = gameState.generateSuccessor(0, move)
				#print "inside caller: a, b: ", a, ", ", b
				#populate values with a list of a value for each corresponding state
				valTemp = self.minFinder(state, 1, self.depth, a, b)
				values.append(valTemp)
				#print "just appended ", valTemp
				if valTemp > maxVal:
					maxVal = valTemp
				if maxVal > a:
					a = maxVal
			
			lengthValues = len(values)
			#print "values being considered by caller: ", values
			i=0
			finalIndex = -1
			while i < lengthValues:
				if values[i] == maxVal:
					finalIndex = i
				i=i+1
			move = legalMoves[finalIndex]
			return move
			
						
	
	def maxFinder(self, gameState, depth, a, b):
		if depth == 0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		maxVal = -99999
		nextStates = []
		legalMoves = gameState.getLegalActions(0)
		for move in legalMoves:
			#print "inside max: a, b: ", a, ", ", b
			state = gameState.generateSuccessor(0,move)
			valTemp = self.minFinder(state, 1, depth, a, b)
			#thus minFinder must return the value of the node.
			if valTemp > maxVal:
				maxVal = valTemp
			if maxVal > b:
				return maxVal
			if maxVal > a:
				#print "max changed to ", valTemp
				a = maxVal
		return maxVal
		
	def minFinder(self, gameState, agent, depth, a, b):
		if depth ==0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		numAgents = gameState.getNumAgents()
		#print "number of agents: ", numAgents
		legalMoves = gameState.getLegalActions(agent)
		nextStates = []
		#generate states for each legal move

		
		#find the min value
		minValue = 999999
		if agent == numAgents -1: #if about to pass to max (pacman)
			for move in legalMoves:
				state = gameState.generateSuccessor(agent, move)
				#print "inside min1: a, b: ", a, ", ", b
				valTemp = self.maxFinder(state,depth-1, a, b)
				if valTemp <minValue:
					minValue = valTemp
				#print "minValue1: ", minValue
				if minValue <a:
					#print "returning: ", minValue
					return minValue
				if minValue < b:
					b = minValue
				
		else:
			for move in legalMoves:
				state = gameState.generateSuccessor(agent, move)
				#print "inside here"
				#print "inside min2: a, b: ", a, ", ", b
				#print "in here"
				valTemp = self.minFinder(state, agent + 1, depth, a, b)
				if valTemp <minValue:
					minValue = valTemp
				#print "minValue2: ", minValue
				if minValue <a:
					return minValue
				if minValue < b:
					b = minValue
		return minValue
	

class ExpectimaxAgent(MultiAgentSearchAgent):
	def getAction(self, gameState):
		if gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		else:
			legalMoves = gameState.getLegalActions(0)
			nextStates = []
			values = []
			for move in legalMoves:
				#generate states for each move
				nextStates.append(gameState.generateSuccessor(0,move))
			for state in nextStates:
				#populate values with a list of a value for each corresponding state
				valTemp = self.avgFinder(state, 1, self.depth)
				values.append(valTemp)
			maxVal = max(values)
			i = 0
			for value in values:
				if value == maxVal:
					maxValIndex =i
				i=i+1
			move = legalMoves[maxValIndex]
			return move
	def maxFinder(self, gameState, depth):
		if depth == 0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		maxVal = -99999
		nextStates = []
		legalMoves = gameState.getLegalActions(0)
		for move in legalMoves:
			nextStates.append(gameState.generateSuccessor(0,move))
		for state in nextStates:
			valTemp = self.avgFinder(state, 1, depth)
			#thus minFinder must return the value of the node.
			if valTemp > maxVal:
				maxVal = valTemp
		return maxVal
	def avgFinder(self, gameState, agent, depth):
		if depth ==0 or gameState.isWin() or gameState.isLose():
			return self.evaluationFunction(gameState)
		numAgents = gameState.getNumAgents()
		legalMoves = gameState.getLegalActions(agent)
		nextStates = []
		#generate states for each legal move
		for move in legalMoves:
			nextStates.append(gameState.generateSuccessor(agent,move))
		#find the min value
		sum = 0.0	
		avg = 0.0
		if agent == numAgents -1:
			for state in nextStates:
				valTemp = self.maxFinder(state,depth-1)
				sum = sum + valTemp
			avg = sum/len(nextStates)
		else:
			for state in nextStates:
				valTemp = self.avgFinder(state, agent+1, depth)
				sum = sum +valTemp
			avg = sum/len(nextStates)
		return avg
		
def betterEvaluationFunction(currentGameState):
	playerPos = currentGameState.getPacmanPosition()
	ghostPositions = currentGameState.getGhostPositions()
	listOfFood = currentGameState.getFood().asList()
	value = 0 
	under4 = 0
	under2 = 0
	foodValue = 0
	
	closestGhostDistance = 9999999
	for pos in ghostPositions:
		distance = util.manhattanDistance(playerPos, pos)
		if distance <2:
			under2 = 1
		elif distance < 4:
			under4
		if distance < closestGhostDistance:
			closestGhostDistance = distance
	###
	ghostValue = -999999*under2 -1000*under4 +100*closestGhostDistance
	###
	minFoodDistance = 100.0
	for pos in listOfFood:
		distance = util.manhattanDistance(playerPos, pos)
		if distance < minFoodDistance:
			minFoodDistance = distance
	amountOfFood = len(listOfFood)
	##
	foodValue = -minFoodDistance - 700*amountOfFood
	## 
	specialDots = -8 *len(currentGameState.getCapsules())
	##
	#print "length of the food array: ", len(listOfFood)
	#print "minFoodDistance, amountOfFood: ", minFoodDistance, ", ", amountOfFood
	
	
	value = .01*ghostValue +foodValue +2*specialDots
	return value
    
    
    
# Abbreviation
better = betterEvaluationFunction

